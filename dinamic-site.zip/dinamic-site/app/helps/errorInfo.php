<?php if (count($errMessage) > 0): ?>
    <ul>
        <?php foreach ($errMessage as $error): ?>
            <li><?=$error; ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif; ?>
